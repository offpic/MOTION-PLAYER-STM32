/*
 * delay.h
 *
 *  Created on: 2011/10/31
 *      Author: Tonsuke
 */

#ifndef DELAY_H_
#define DELAY_H_


extern void Delayms(int i);
extern void Delay(int i);


#endif /* DELAY_H_ */
