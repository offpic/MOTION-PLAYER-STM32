/*
 * HMC5883L.h
 *
 *  Created on: 2014/05/28
 *      Author: masayuki
 */

#ifndef HMC5883L_H_
#define HMC5883L_H_

#define I2C_ADDRESS_HMC5883L 0x3C


extern void HMC5883L();

#endif /* HMC5883L_H_ */
